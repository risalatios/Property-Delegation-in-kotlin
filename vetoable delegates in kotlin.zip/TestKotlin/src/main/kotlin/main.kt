import kotlin.properties.Delegates

fun main() {

    val student = Student()
    student.marks = 30
    println("${student.marks}")
    student.marks = 45
    println("${student.marks}")
}

// if i assign a value to a property then first the value is assigned and then the handler is called
// but in case we want to intercept the assinment and wants the handler to be called first in that case
// we use vetoable delegate

class Student {
    var marks: Int by Delegates.vetoable(0) { property, oldValue, newValue ->
        newValue > 33
    }
}