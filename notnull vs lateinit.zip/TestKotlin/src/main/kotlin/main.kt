import kotlin.properties.Delegates

fun main() {

    student = Student()
    println(student)
    marks = 90
print(marks)

    newStudent = Student()
    print(newStudent)


}

lateinit var newStudent: Student
var marks: Int by Delegates.notNull()
var student: Student by Delegates.notNull()
class Student {
    var name = ""
}

