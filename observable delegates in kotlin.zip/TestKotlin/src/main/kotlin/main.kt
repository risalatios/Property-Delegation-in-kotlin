import kotlin.properties.Delegates

fun main() {
val student = Student("xyz")
    student.marks = 550
    student.marks = 660
}
// Observable delegates is the handler will be called only after the initialization has been performed.
// after the assignment has been performed
class Student(val name: String){
    var marks: Int by Delegates.observable(0) { prop, oldmarks, newMarks ->
        println("${prop}, ${oldmarks}, ${newMarks}")
    }
}
