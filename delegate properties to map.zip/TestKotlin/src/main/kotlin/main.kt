import kotlin.properties.Delegates

fun main() {

var json = mutableMapOf<String, Any>("name" to "khan", "age" to 35)
    val student = Student(json)
    println("${student.name}")
    json["name"] = "kkk"
    println("${student.name}")
}

class Student(val json: MutableMap<String, Any>){
    val name: String by json
    val marks: Int by json
}