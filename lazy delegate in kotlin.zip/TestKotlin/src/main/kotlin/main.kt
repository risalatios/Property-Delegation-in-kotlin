

fun main() {
val student = Student("Dhayan")
println(student.hostel)
}

// lazy(it is something that computed lazily or whenever required or on first access

class Student(val name:String) {
    val hostel: Hostel by lazy {
        Hostel("xyz", 200)
    }
    init {
        println("I am student object")
    }
}

class Hostel(val name: String, val roomNo: Int) {
    init {
        println("I am hostel object")
    }
}