import java.time.LocalDateTime
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

fun main(args: Array<String>) {
val student = Student("aaaaa", "bbbbb")
    student.firstName = "HHHhnsnd"

    println("${student.firstName}, ${student.lastName}, ${student.lastUpdate}")
}


class Student(fname: String, lName:String) {
    var firstName: String by NameFormatter()
    var lastUpdate: LocalDateTime = LocalDateTime.now()
    var lastName: String by NameFormatter()
}

class NameFormatter: ReadWriteProperty<Any, String> {
    var formattedName = ""
    override fun setValue(thisRef: Any, property: KProperty<*>, value: String) {
     formattedName = value.toLowerCase().capitalize()
        if (thisRef is Student) {
            thisRef.lastUpdate = LocalDateTime.now()
        }
    }

    override fun getValue(thisRef: Any, property: KProperty<*>): String {
        return  formattedName

    }
}
